const menuToggle=document.querySelector('.menu-toggle');const nav=document.querySelector('#siteNav');
if(menuToggle&&nav){menuToggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');menuToggle.setAttribute('aria-expanded',open);menuToggle.textContent=open?'×':'☰'});nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');menuToggle.setAttribute('aria-expanded','false');menuToggle.textContent='☰'}));}
const contactForm=document.querySelector('#contactForm');const appointmentForm=document.querySelector('#appointmentForm');
function handleDemo(form,message){if(!form)return;form.addEventListener('submit',e=>{e.preventDefault();const out=form.querySelector('.form-message');out.textContent=message;form.reset();});}
handleDemo(contactForm,'Thank you. Your message has been received. Connect this form to your email service or backend to receive submissions.');
handleDemo(appointmentForm,'Thank you. Your appointment request has been recorded on this demo page. Connect the form to your booking system to process real appointments.');
const date=document.querySelector('#date');if(date){const today=new Date();const local=new Date(today.getTime()-today.getTimezoneOffset()*60000).toISOString().split('T')[0];date.min=local;}
